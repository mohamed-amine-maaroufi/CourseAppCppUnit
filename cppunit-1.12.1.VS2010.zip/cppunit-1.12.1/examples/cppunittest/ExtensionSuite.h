#ifndef CPPUNITTEST_EXTENSIONSSUITE_H
#define CPPUNITTEST_EXTENSIONSSUITE_H

#include <cppunit/Portability.h>
#include <string>

inline std::string extensionSuiteName()
{
  return "Extensions";
}

#endif // CPPUNITTEST_EXTENSIONSSUITE_H
